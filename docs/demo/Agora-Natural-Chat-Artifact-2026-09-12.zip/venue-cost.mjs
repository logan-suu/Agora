/**
 * Computes the venue cost in integer cents for a given number of hours.
 *
 * @param {number} hours - Non-negative integer number of hours.
 * @returns {number} The venue cost in cents (hours * 5000).
 * @throws {RangeError} If hours is negative, fractional, non-finite, or not a number.
 */
export function venueCost(hours) {
  if (!Number.isInteger(hours) || hours < 0) {
    throw new RangeError('hours must be a non-negative integer');
  }
  return hours * 5000;
}