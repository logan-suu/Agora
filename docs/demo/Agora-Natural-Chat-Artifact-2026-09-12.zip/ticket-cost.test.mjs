import test from 'node:test';
import assert from 'node:assert/strict';
import { ticketCost } from './ticket-cost.mjs';

test('ticket-cost module exports the ticketCost function', () => {
  assert.equal(typeof ticketCost, 'function');
});

test('ticketCost(0) returns 0', () => {
  assert.equal(ticketCost(0), 0);
});

test('ticketCost returns attendees * 900 for non-negative integers', () => {
  assert.equal(ticketCost(1), 900);
  assert.equal(ticketCost(3), 2700);
  assert.equal(ticketCost(10), 9000);
  assert.equal(ticketCost(100), 90000);
});

test('ticketCost throws RangeError for negative, fractional, or non-finite inputs', () => {
  for (const invalid of [-1, 2.5, NaN, Infinity, -Infinity]) {
    assert.throws(() => ticketCost(invalid), RangeError);
  }
});

test('ticketCost throws RangeError for non-number inputs', () => {
  for (const invalid of ['3', null, undefined, {}]) {
    assert.throws(() => ticketCost(invalid), RangeError);
  }
});

test('ticketCost throws RangeError for Symbol and null-prototype object inputs', () => {
  for (const invalid of [Symbol('invalid'), Object.create(null)]) {
    assert.throws(() => ticketCost(invalid), RangeError);
  }
});