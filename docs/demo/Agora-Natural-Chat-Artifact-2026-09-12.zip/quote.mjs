import { ticketCost } from './ticket-cost.mjs';
import { venueCost } from './venue-cost.mjs';

/**
 * Computes a full event quote combining ticket and venue costs.
 *
 * @param {number} attendees - Number of attendees; must be a non-negative integer.
 * @param {number} hours - Number of venue hours; must be a non-negative integer.
 * @returns {{ ticketCost: number, venueCost: number, total: number }} The ticket
 *   cost, venue cost, and total, all in integer cents.
 * @throws {RangeError} If either argument is negative, fractional, non-finite, or
 *   not a number. The error from the underlying module propagates unchanged.
 */
export function quote(attendees, hours) {
  const tickets = ticketCost(attendees);
  const venue = venueCost(hours);
  return { ticketCost: tickets, venueCost: venue, total: tickets + venue };
}