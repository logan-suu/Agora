import test from 'node:test';
import assert from 'node:assert/strict';
import { quote } from './quote.mjs';

test('quote module exports the quote function', () => {
  assert.equal(typeof quote, 'function');
});

test('quote(0, 0) returns all-zero costs', () => {
  assert.deepEqual(quote(0, 0), { ticketCost: 0, venueCost: 0, total: 0 });
});

test('quote returns ticketCost, venueCost, and total in integer cents for non-negative integers', () => {
  assert.deepEqual(quote(1, 1), { ticketCost: 900, venueCost: 5000, total: 5900 });
  assert.deepEqual(quote(3, 2), { ticketCost: 2700, venueCost: 10000, total: 12700 });
  assert.deepEqual(quote(10, 4), { ticketCost: 9000, venueCost: 20000, total: 29000 });
});

test('quote throws RangeError for negative, fractional, or non-finite attendees or hours', () => {
  for (const invalid of [-1, 2.5, NaN, Infinity, -Infinity]) {
    assert.throws(() => quote(invalid, 1), RangeError);
    assert.throws(() => quote(1, invalid), RangeError);
  }
});

test('quote throws RangeError for non-number inputs', () => {
  for (const invalid of ['3', null, undefined, {}]) {
    assert.throws(() => quote(invalid, 1), RangeError);
    assert.throws(() => quote(1, invalid), RangeError);
  }
});

test('quote throws RangeError for Symbol and null-prototype object inputs in either argument', () => {
  for (const invalid of [Symbol('invalid'), Object.create(null)]) {
    assert.throws(() => quote(invalid, 1), RangeError);
    assert.throws(() => quote(1, invalid), RangeError);
  }
});