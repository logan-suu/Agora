/**
 * Computes the ticket cost for an event.
 *
 * @param {number} attendees - Number of attendees; must be a non-negative integer.
 * @returns {number} The ticket cost in integer cents (900 cents per attendee).
 * @throws {RangeError} If `attendees` is negative, fractional, non-finite, or not a number.
 */
export function ticketCost(attendees) {
  if (!Number.isInteger(attendees) || attendees < 0) {
    throw new RangeError('ticketCost expects attendees to be a non-negative integer');
  }
  return attendees * 900;
}