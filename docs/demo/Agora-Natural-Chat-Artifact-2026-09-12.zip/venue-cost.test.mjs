import test from 'node:test';
import assert from 'node:assert/strict';
import { venueCost } from './venue-cost.mjs';

test('venue-cost module exports the venueCost function', () => {
  assert.equal(typeof venueCost, 'function');
});

test('venueCost(0) returns 0', () => {
  assert.equal(venueCost(0), 0);
});

test('venueCost returns hours * 5000 for non-negative integers', () => {
  assert.equal(venueCost(1), 5000);
  assert.equal(venueCost(4), 20000);
  assert.equal(venueCost(10), 50000);
  assert.equal(venueCost(100), 500000);
});

test('venueCost throws RangeError for negative, fractional, or non-finite inputs', () => {
  for (const invalid of [-1, 2.5, NaN, Infinity, -Infinity]) {
    assert.throws(() => venueCost(invalid), RangeError);
  }
});

test('venueCost throws RangeError for non-number inputs', () => {
  for (const invalid of ['3', null, undefined, {}]) {
    assert.throws(() => venueCost(invalid), RangeError);
  }
});

test('venueCost throws RangeError for Symbol and null-prototype object inputs', () => {
  for (const invalid of [Symbol('invalid'), Object.create(null)]) {
    assert.throws(() => venueCost(invalid), RangeError);
  }
});