// quote.mjs
//
// Exports quote(attendees, hours), which computes the complete cost
// breakdown of an event quote using ticketCost and venueCost.

import { ticketCost } from './ticket.mjs';
import { venueCost } from './venue.mjs';

/**
 * Computes a complete event quote.
 *
 * @param {number} attendees - Number of attendees (non-negative integer).
 * @param {number} hours - Number of venue hours (non-negative integer).
 * @returns {{ tickets: number, venue: number, total: number }} Cost
 *   breakdown in cents.
 * @throws {RangeError} If either parameter is not a non-negative integer.
 */
export function quote(attendees, hours) {
  if (
    typeof attendees !== 'number' ||
    !Number.isInteger(attendees) ||
    attendees < 0
  ) {
    throw new RangeError('attendees must be a non-negative integer');
  }
  if (
    typeof hours !== 'number' ||
    !Number.isInteger(hours) ||
    hours < 0
  ) {
    throw new RangeError('hours must be a non-negative integer');
  }

  const tickets = ticketCost(attendees);
  const venue = venueCost(hours);
  return { tickets, venue, total: tickets + venue };
}