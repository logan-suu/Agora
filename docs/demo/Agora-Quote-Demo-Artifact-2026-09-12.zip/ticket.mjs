export function ticketCost(attendees) {
  if (
    typeof attendees !== 'number' ||
    !Number.isInteger(attendees) ||
    attendees < 0
  ) {
    throw new RangeError('attendees must be a non-negative integer');
  }
  return attendees * 900;
}