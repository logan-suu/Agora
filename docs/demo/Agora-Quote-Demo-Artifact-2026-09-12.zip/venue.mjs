// venue.mjs
//
// Exports venueCost(hours), which computes the venue portion of an
// event quote as hours * 5000 cents.

/**
 * Computes the venue cost for the given number of hours.
 *
 * @param {number} hours - Number of hours the venue is booked.
 * @returns {number} The venue cost in cents (hours * 5000).
 * @throws {RangeError} If hours is not a non-negative integer.
 */
export function venueCost(hours) {
  if (typeof hours !== 'number' || !Number.isInteger(hours) || hours < 0) {
    throw new RangeError('hours must be a non-negative integer');
  }
  return hours * 5000;
}