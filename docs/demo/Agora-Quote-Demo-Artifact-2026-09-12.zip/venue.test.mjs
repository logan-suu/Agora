// venue.test.mjs
//
// Tests for venueCost covering normal values, zero, negative values,
// fractional values, Symbol values, Object.create(null), and other
// invalid inputs.

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { venueCost } from './venue.mjs';

test('venueCost returns hours * 5000 for normal values', () => {
  assert.equal(venueCost(1), 5000);
  assert.equal(venueCost(2), 10000);
  assert.equal(venueCost(3), 15000);
  assert.equal(venueCost(10), 50000);
});

test('venueCost accepts zero as a valid input', () => {
  assert.equal(venueCost(0), 0);
});

test('venueCost throws RangeError for negative values', () => {
  assert.throws(() => venueCost(-1), RangeError);
  assert.throws(() => venueCost(-100), RangeError);
});

test('venueCost throws RangeError for fractional values', () => {
  assert.throws(() => venueCost(0.5), RangeError);
  assert.throws(() => venueCost(2.5), RangeError);
});

test('venueCost throws RangeError for Symbol values', () => {
  assert.throws(() => venueCost(Symbol('hours')), RangeError);
});

test('venueCost throws RangeError for Object.create(null)', () => {
  assert.throws(() => venueCost(Object.create(null)), RangeError);
});

test('venueCost throws RangeError for other invalid inputs', () => {
  assert.throws(() => venueCost('2'), RangeError);
  assert.throws(() => venueCost(null), RangeError);
  assert.throws(() => venueCost(undefined), RangeError);
  assert.throws(() => venueCost(true), RangeError);
  assert.throws(() => venueCost(NaN), RangeError);
  assert.throws(() => venueCost(Infinity), RangeError);
  assert.throws(() => venueCost(-Infinity), RangeError);
  assert.throws(() => venueCost({}), RangeError);
  assert.throws(() => venueCost([]), RangeError);
});