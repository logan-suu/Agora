// quote.test.mjs
//
// Tests for quote covering normal values, zero, and invalid inputs for
// each parameter independently.

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { quote } from './quote.mjs';

test('quote returns the full cost breakdown for normal values', () => {
  assert.deepEqual(quote(2, 3), { tickets: 1800, venue: 15000, total: 16800 });
  assert.deepEqual(quote(1, 1), { tickets: 900, venue: 5000, total: 5900 });
  assert.deepEqual(quote(10, 2), { tickets: 9000, venue: 10000, total: 19000 });
});

test('quote accepts zero for both parameters', () => {
  assert.deepEqual(quote(0, 0), { tickets: 0, venue: 0, total: 0 });
  assert.deepEqual(quote(0, 3), { tickets: 0, venue: 15000, total: 15000 });
  assert.deepEqual(quote(2, 0), { tickets: 1800, venue: 0, total: 1800 });
});

test('quote throws RangeError when attendees is negative', () => {
  assert.throws(() => quote(-1, 3), RangeError);
  assert.throws(() => quote(-100, 0), RangeError);
});

test('quote throws RangeError when hours is negative', () => {
  assert.throws(() => quote(2, -1), RangeError);
  assert.throws(() => quote(0, -100), RangeError);
});

test('quote throws RangeError when attendees is fractional', () => {
  assert.throws(() => quote(1.5, 3), RangeError);
  assert.throws(() => quote(0.25, 3), RangeError);
});

test('quote throws RangeError when hours is fractional', () => {
  assert.throws(() => quote(2, 1.5), RangeError);
  assert.throws(() => quote(2, 0.25), RangeError);
});

test('quote throws RangeError when attendees is a Symbol', () => {
  assert.throws(() => quote(Symbol('attendees'), 3), RangeError);
});

test('quote throws RangeError when hours is a Symbol', () => {
  assert.throws(() => quote(2, Symbol('hours')), RangeError);
});

test('quote throws RangeError when attendees is Object.create(null)', () => {
  assert.throws(() => quote(Object.create(null), 3), RangeError);
});

test('quote throws RangeError when hours is Object.create(null)', () => {
  assert.throws(() => quote(2, Object.create(null)), RangeError);
});

test('quote throws RangeError for other invalid attendees inputs', () => {
  assert.throws(() => quote('3', 3), RangeError);
  assert.throws(() => quote(null, 3), RangeError);
  assert.throws(() => quote(undefined, 3), RangeError);
  assert.throws(() => quote(true, 3), RangeError);
  assert.throws(() => quote(NaN, 3), RangeError);
  assert.throws(() => quote(Infinity, 3), RangeError);
  assert.throws(() => quote({}, 3), RangeError);
  assert.throws(() => quote([], 3), RangeError);
});

test('quote throws RangeError for other invalid hours inputs', () => {
  assert.throws(() => quote(2, '3'), RangeError);
  assert.throws(() => quote(2, null), RangeError);
  assert.throws(() => quote(2, undefined), RangeError);
  assert.throws(() => quote(2, true), RangeError);
  assert.throws(() => quote(2, NaN), RangeError);
  assert.throws(() => quote(2, Infinity), RangeError);
  assert.throws(() => quote(2, {}), RangeError);
  assert.throws(() => quote(2, []), RangeError);
});