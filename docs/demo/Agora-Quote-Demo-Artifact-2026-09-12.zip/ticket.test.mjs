import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ticketCost } from './ticket.mjs';

test('ticketCost returns attendees * 900 for normal values', () => {
  assert.equal(ticketCost(1), 900);
  assert.equal(ticketCost(2), 1800);
  assert.equal(ticketCost(10), 9000);
});

test('ticketCost accepts zero', () => {
  assert.equal(ticketCost(0), 0);
});

test('ticketCost throws RangeError for negative values', () => {
  assert.throws(() => ticketCost(-1), RangeError);
  assert.throws(() => ticketCost(-100), RangeError);
});

test('ticketCost throws RangeError for fractional values', () => {
  assert.throws(() => ticketCost(1.5), RangeError);
  assert.throws(() => ticketCost(0.25), RangeError);
});

test('ticketCost throws RangeError for Symbol values', () => {
  assert.throws(() => ticketCost(Symbol('attendees')), RangeError);
});

test('ticketCost throws RangeError for Object.create(null)', () => {
  assert.throws(() => ticketCost(Object.create(null)), RangeError);
});

test('ticketCost throws RangeError for other invalid inputs', () => {
  assert.throws(() => ticketCost('3'), RangeError);
  assert.throws(() => ticketCost(null), RangeError);
  assert.throws(() => ticketCost(undefined), RangeError);
  assert.throws(() => ticketCost(NaN), RangeError);
  assert.throws(() => ticketCost(Infinity), RangeError);
  assert.throws(() => ticketCost({}), RangeError);
  assert.throws(() => ticketCost([]), RangeError);
});